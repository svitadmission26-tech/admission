import os, io, datetime, secrets
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Request
from fastapi.responses import StreamingResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from sqlalchemy.orm import Session
from sqlalchemy import select, func
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill
from passlib.context import CryptContext
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from .db import Base, engine, SessionLocal
from . import models as m
from dotenv import load_dotenv
load_dotenv()
secret=os.getenv('SECRET_KEY')
if not secret or secret.startswith('CHANGE_ME'): raise RuntimeError('Set SECRET_KEY in .env')
serializer=URLSafeTimedSerializer(secret)
pwd=CryptContext(schemes=['bcrypt'],deprecated='auto')
@asynccontextmanager
async def lifespan(app):
 Base.metadata.create_all(engine)
 with SessionLocal() as db:
  if not db.scalar(select(m.User).limit(1)):
   username=os.getenv('ADMIN_USERNAME','admin'); password=os.getenv('ADMIN_PASSWORD','')
   if not password or password.startswith('CHANGE_ME'): raise RuntimeError('Set ADMIN_PASSWORD in .env')
   db.add(m.User(username=username,password_hash=pwd.hash(password),role='ADMIN')); db.commit()
 yield
app=FastAPI(title='College Management Starter',lifespan=lifespan)
app.mount('/static',StaticFiles(directory='static'),name='static'); views=Jinja2Templates(directory='templates')
def db_session():
 with SessionLocal() as db: yield db
def user(request:Request,db:Session=Depends(db_session)):
 token=request.cookies.get('session')
 if not token: raise HTTPException(401,'Login required')
 try: uid=serializer.loads(token,max_age=28800)
 except (BadSignature,SignatureExpired): raise HTTPException(401,'Session expired')
 u=db.get(m.User,uid)
 if not u: raise HTTPException(401,'Unknown user')
 return u
def roles(*allowed):
 def check(u=Depends(user)):
  if u.role not in allowed: raise HTTPException(403,'Not permitted')
  return u
 return check
class Login(BaseModel): username:str; password:str
@app.get('/',response_class=HTMLResponse)
def home(request:Request): return views.TemplateResponse(request,'index.html')
@app.post('/api/login')
def login(data:Login,db:Session=Depends(db_session)):
 u=db.scalar(select(m.User).where(m.User.username==data.username))
 if not u or not pwd.verify(data.password,u.password_hash): raise HTTPException(401,'Invalid credentials')
 from fastapi.responses import JSONResponse
 r=JSONResponse({'role':u.role,'username':u.username}); r.set_cookie('session',serializer.dumps(u.id),httponly=True,samesite='lax',secure=os.getenv('COOKIE_SECURE','false').lower()=='true',max_age=28800); return r
@app.post('/api/logout')
def logout():
 from fastapi.responses import JSONResponse
 r=JSONResponse({'ok':True}); r.delete_cookie('session'); return r
@app.get('/api/me')
def me(u=Depends(user)): return {'username':u.username,'role':u.role,'faculty_id':u.faculty_id}
SCHEMAS={'faculty':(m.Faculty,['code','name','department']),'students':(m.Student,['enrollment','name','course','semester','division']),'subjects':(m.Subject,['code','name','course','semester']),'inquiries':(m.Inquiry,['name','phone','course']),'intakes':(m.Intake,['course','capacity'])}
def master(module):
 if module not in SCHEMAS: raise HTTPException(404,'Unknown module')
 return SCHEMAS[module]
@app.get('/api/master/{module}')
def list_master(module:str,db:Session=Depends(db_session),u=Depends(user)):
 model,cols=master(module)
 if u.role=='FACULTY' and module not in ('students','subjects','faculty'): raise HTTPException(403)
 return [{k:getattr(x,k) for k in ['id']+cols} for x in db.scalars(select(model).order_by(model.id)).all()]
@app.post('/api/master/{module}')
def add_master(module:str,values:dict,db:Session=Depends(db_session),u=Depends(roles('ADMIN','HOD'))):
 model,cols=master(module)
 if module in ('intakes','inquiries') and u.role!='ADMIN': raise HTTPException(403)
 if set(values)-set(cols): raise HTTPException(400,'Unknown fields')
 try:
  item=model(**{c:values[c] for c in cols}); db.add(item); db.commit(); db.refresh(item); return {'id':item.id}
 except (KeyError,ValueError,TypeError) as e: db.rollback(); raise HTTPException(400,str(e))
 except Exception: db.rollback(); raise HTTPException(409,'Duplicate or invalid entry')
@app.put('/api/master/{module}/{item_id}')
def edit_master(module:str,item_id:int,values:dict,db:Session=Depends(db_session),u=Depends(roles('ADMIN','HOD'))):
 model,cols=master(module)
 if module in ('intakes','inquiries') and u.role!='ADMIN': raise HTTPException(403)
 item=db.get(model,item_id)
 if not item: raise HTTPException(404)
 if set(values)-set(cols): raise HTTPException(400,'Unknown fields')
 for k,v in values.items(): setattr(item,k,v)
 try: db.commit(); return {'ok':True}
 except Exception: db.rollback(); raise HTTPException(409,'Duplicate or invalid update')
@app.delete('/api/master/{module}/{item_id}')
def delete_master(module:str,item_id:int,db:Session=Depends(db_session),u=Depends(roles('ADMIN'))):
 model,_=master(module); item=db.get(model,item_id)
 if not item: raise HTTPException(404)
 try: db.delete(item); db.commit(); return {'ok':True}
 except Exception: db.rollback(); raise HTTPException(409,'Record is referenced; cannot delete')
@app.get('/api/template/{module}')
def template(module:str,u=Depends(roles('ADMIN','HOD'))):
 _,cols=master(module); wb=Workbook(); ws=wb.active; ws.title=module; ws.append(cols); ws.freeze_panes='A2'; ws.auto_filter.ref=f'A1:{chr(64+len(cols))}1'
 for c in ws[1]: c.font=Font(bold=True,color='FFFFFF'); c.fill=PatternFill('solid',fgColor='17406D')
 for i,c in enumerate(cols,1): ws.column_dimensions[chr(64+i)].width=max(17,len(c)+5)
 out=io.BytesIO(); wb.save(out); out.seek(0)
 return StreamingResponse(out,media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',headers={'Content-Disposition':f'attachment; filename="{module}_template.xlsx"'})
@app.get('/api/export/{module}')
def export(module:str,db:Session=Depends(db_session),u=Depends(roles('ADMIN','HOD'))):
 model,cols=master(module); wb=Workbook(); ws=wb.active; ws.append(['id']+cols)
 for x in db.scalars(select(model)).all(): ws.append([getattr(x,c) for c in ['id']+cols])
 out=io.BytesIO(); wb.save(out); out.seek(0)
 return StreamingResponse(out,media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',headers={'Content-Disposition':f'attachment; filename="{module}_export.xlsx"'})
@app.post('/api/import/{module}')
async def import_excel(module:str,file:UploadFile=File(...),db:Session=Depends(db_session),u=Depends(roles('ADMIN','HOD'))):
 model,cols=master(module)
 if module in ('intakes','inquiries') and u.role!='ADMIN': raise HTTPException(403)
 data=await file.read()
 if len(data)>5_000_000 or not file.filename.lower().endswith('.xlsx'): raise HTTPException(400,'Only .xlsx up to 5MB')
 try:
  ws=load_workbook(io.BytesIO(data),read_only=True,data_only=True).active; rows=ws.iter_rows(values_only=True); header=next(rows)
  if list(header[:len(cols)])!=cols: raise HTTPException(400,f'Expected columns: {cols}')
  entries=[]; errors=[]
  for n,row in enumerate(rows,2):
   if not any(v is not None for v in row): continue
   if len(entries)>=2000: raise HTTPException(400,'Maximum 2000 rows')
   values=dict(zip(cols,row)); missing=[k for k,v in values.items() if v is None or v=='']
   if missing: errors.append({'row':n,'error':'Missing: '+','.join(missing)}); continue
   entries.append(model(**values))
  if errors: return {'imported':0,'errors':errors}
  db.add_all(entries); db.commit(); return {'imported':len(entries),'errors':[]}
 except HTTPException: raise
 except Exception as e: db.rollback(); raise HTTPException(400,'Invalid workbook or duplicate/invalid data: '+str(e)[:180])
class InquiryAdmission(BaseModel): inquiry_id:int
@app.post('/api/admissions/finalize')
def finalize(d:InquiryAdmission,db:Session=Depends(db_session),u=Depends(roles('ADMIN'))):
 q=db.get(m.Inquiry,d.inquiry_id)
 if not q: raise HTTPException(404)
 if db.scalar(select(m.Admission).where(m.Admission.inquiry_id==q.id)): raise HTTPException(409,'Admission already exists')
 cap=db.scalar(select(m.Intake).where(m.Intake.course==q.course))
 if not cap: raise HTTPException(400,'Configure course intake first')
 used=db.scalar(select(func.count()).select_from(m.Admission).join(m.Inquiry,m.Admission.inquiry_id==m.Inquiry.id).where(m.Inquiry.course==q.course,m.Admission.status=='FINAL'))
 if used>=cap.capacity: raise HTTPException(409,'Intake full')
 db.add(m.Admission(inquiry_id=q.id,status='FINAL')); q.status='ADMITTED'; db.commit(); return {'ok':True,'remaining':cap.capacity-used-1}
@app.post('/api/admissions/{admission_id}/cancel')
def cancel(admission_id:int,db:Session=Depends(db_session),u=Depends(roles('ADMIN'))):
 a=db.get(m.Admission,admission_id)
 if not a or a.status!='FINAL': raise HTTPException(404)
 a.status='CANCELLED'; db.get(m.Inquiry,a.inquiry_id).status='NOT_ADMITTED'; db.commit(); return {'ok':True}
@app.get('/api/admissions')
def admissions(db:Session=Depends(db_session),u=Depends(roles('ADMIN'))):
 return [{'id':a.id,'inquiry_id':a.inquiry_id,'status':a.status} for a in db.scalars(select(m.Admission)).all()]
class Account(BaseModel): username:str; password:str; role:str; faculty_id:int|None=None
@app.post('/api/accounts')
def account(d:Account,db:Session=Depends(db_session),u=Depends(roles('ADMIN'))):
 if d.role not in ('ADMIN','HOD','FACULTY') or len(d.password)<10: raise HTTPException(400,'Invalid role or password too short')
 if d.role=='FACULTY' and (not d.faculty_id or not db.get(m.Faculty,d.faculty_id)): raise HTTPException(400,'Faculty required')
 db.add(m.User(username=d.username,password_hash=pwd.hash(d.password),role=d.role,faculty_id=d.faculty_id))
 try: db.commit(); return {'ok':True}
 except Exception: db.rollback(); raise HTTPException(409,'Username already exists')
class SlotIn(BaseModel): day:str; period:int; faculty_id:int; subject_id:int; course:str; semester:int; division:str; room:str=''
@app.post('/api/slots')
def create_slot(d:SlotIn,db:Session=Depends(db_session),u=Depends(roles('ADMIN','HOD'))):
 if d.day not in ('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') or d.period<1: raise HTTPException(400)
 subject=db.get(m.Subject,d.subject_id)
 if not db.get(m.Faculty,d.faculty_id) or not subject or (subject.course,subject.semester)!=(d.course,d.semester): raise HTTPException(400,'Invalid faculty or subject')
 db.add(m.Slot(**d.model_dump()))
 try: db.commit(); return {'ok':True}
 except Exception: db.rollback(); raise HTTPException(409,'Faculty/class timetable clash')
@app.get('/api/slots')
def slots(db:Session=Depends(db_session),u=Depends(user)):
 rows=db.scalars(select(m.Slot)).all()
 if u.role=='FACULTY': rows=[x for x in rows if x.faculty_id==u.faculty_id]
 return [{k:getattr(x,k) for k in ('id','day','period','faculty_id','subject_id','course','semester','division','room')} for x in rows]
class LeaveIn(BaseModel): faculty_id:int; start:datetime.date; end:datetime.date; leave_type:str; reason:str=''
@app.post('/api/leaves')
def apply_leave(d:LeaveIn,db:Session=Depends(db_session),u=Depends(user)):
 if u.role=='FACULTY' and u.faculty_id!=d.faculty_id: raise HTTPException(403)
 if d.end<d.start or not db.get(m.Faculty,d.faculty_id): raise HTTPException(400)
 item=m.Leave(**d.model_dump()); db.add(item); db.commit(); db.refresh(item); return {'id':item.id,'status':item.status}
@app.get('/api/leaves')
def leaves(db:Session=Depends(db_session),u=Depends(user)):
 q=select(m.Leave)
 if u.role=='FACULTY': q=q.where(m.Leave.faculty_id==u.faculty_id)
 return [{'id':x.id,'faculty_id':x.faculty_id,'start':x.start,'end':x.end,'leave_type':x.leave_type,'reason':x.reason,'status':x.status} for x in db.scalars(q).all()]
@app.post('/api/leaves/{leave_id}/{decision}')
def decide_leave(leave_id:int,decision:str,db:Session=Depends(db_session),u=Depends(roles('ADMIN','HOD'))):
 x=db.get(m.Leave,leave_id)
 if not x or x.status!='PENDING' or decision not in ('approve','reject'): raise HTTPException(400)
 x.status='APPROVED' if decision=='approve' else 'REJECTED'; db.commit(); return {'status':x.status}
class ProxyIn(BaseModel): slot_id:int; lecture_date:datetime.date; proxy_faculty_id:int
@app.post('/api/proxies')
def assign_proxy(d:ProxyIn,db:Session=Depends(db_session),u=Depends(roles('ADMIN','HOD'))):
 s=db.get(m.Slot,d.slot_id)
 if not s or not db.get(m.Faculty,d.proxy_faculty_id) or d.proxy_faculty_id==s.faculty_id: raise HTTPException(400,'Invalid proxy')
 if d.lecture_date.strftime('%A')!=s.day: raise HTTPException(400,'Date does not match slot day')
 leave=db.scalar(select(m.Leave).where(m.Leave.faculty_id==s.faculty_id,m.Leave.status=='APPROVED',m.Leave.start<=d.lecture_date,m.Leave.end>=d.lecture_date))
 if not leave: raise HTTPException(400,'Original faculty has no approved leave')
 occupied=db.scalar(select(m.Slot).where(m.Slot.faculty_id==d.proxy_faculty_id,m.Slot.day==s.day,m.Slot.period==s.period))
 other=db.scalar(select(m.Proxy).join(m.Slot,m.Proxy.slot_id==m.Slot.id).where(m.Proxy.proxy_faculty_id==d.proxy_faculty_id,m.Proxy.lecture_date==d.lecture_date,m.Slot.period==s.period,m.Proxy.status=='ASSIGNED'))
 if occupied or other: raise HTTPException(409,'Proxy faculty already busy')
 db.add(m.Proxy(slot_id=s.id,lecture_date=d.lecture_date,original_faculty_id=s.faculty_id,proxy_faculty_id=d.proxy_faculty_id))
 try: db.commit(); return {'ok':True}
 except Exception: db.rollback(); raise HTTPException(409,'Proxy already assigned')
@app.get('/api/proxies')
def proxies(db:Session=Depends(db_session),u=Depends(user)):
 q=select(m.Proxy)
 if u.role=='FACULTY': q=q.where((m.Proxy.proxy_faculty_id==u.faculty_id)|(m.Proxy.original_faculty_id==u.faculty_id))
 return [{k:getattr(x,k) for k in ('id','slot_id','lecture_date','original_faculty_id','proxy_faculty_id','status')} for x in db.scalars(q).all()]
@app.post('/api/proxies/{proxy_id}/cancel')
def cancel_proxy(proxy_id:int,db:Session=Depends(db_session),u=Depends(roles('ADMIN','HOD'))):
 p=db.get(m.Proxy,proxy_id)
 if not p: raise HTTPException(404)
 if db.scalar(select(m.Attendance.id).where(m.Attendance.slot_id==p.slot_id,m.Attendance.lecture_date==p.lecture_date)): raise HTTPException(409,'Attendance exists; cannot cancel')
 p.status='CANCELLED'; db.commit(); return {'ok':True}
@app.get('/api/my-timetable')
def my_timetable(db:Session=Depends(db_session),u=Depends(user)):
 if u.role!='FACULTY': raise HTTPException(403)
 regular=[{'slot_id':s.id,'day':s.day,'period':s.period,'subject_id':s.subject_id,'type':'REGULAR'} for s in db.scalars(select(m.Slot).where(m.Slot.faculty_id==u.faculty_id)).all()]
 proxy=[{'slot_id':p.slot_id,'date':p.lecture_date,'original_faculty_id':p.original_faculty_id,'type':'PROXY'} for p in db.scalars(select(m.Proxy).where(m.Proxy.proxy_faculty_id==u.faculty_id,m.Proxy.status=='ASSIGNED')).all()]
 return {'regular':regular,'proxy':proxy}
@app.get('/api/attendance/roster/{slot_id}/{lecture_date}')
def roster(slot_id:int,lecture_date:datetime.date,db:Session=Depends(db_session),u=Depends(user)):
 s=db.get(m.Slot,slot_id)
 if not s or lecture_date.strftime('%A')!=s.day: raise HTTPException(400,'Invalid lecture')
 p=db.scalar(select(m.Proxy).where(m.Proxy.slot_id==slot_id,m.Proxy.lecture_date==lecture_date,m.Proxy.status=='ASSIGNED'))
 taker=p.proxy_faculty_id if p else s.faculty_id
 if u.role=='FACULTY' and u.faculty_id!=taker: raise HTTPException(403)
 students=db.scalars(select(m.Student).where(m.Student.course==s.course,m.Student.semester==s.semester,m.Student.division==s.division)).all()
 existing={a.student_id:a.present for a in db.scalars(select(m.Attendance).where(m.Attendance.slot_id==slot_id,m.Attendance.lecture_date==lecture_date)).all()}
 return {'type':'PROXY' if p else 'REGULAR','taken_by':taker,'subject_id':s.subject_id,'students':[{'id':x.id,'enrollment':x.enrollment,'name':x.name,'present':existing.get(x.id)} for x in students],'submitted':bool(existing)}
class AttendanceIn(BaseModel): slot_id:int; lecture_date:datetime.date; entries:dict[int,bool]
@app.post('/api/attendance')
def attendance(d:AttendanceIn,db:Session=Depends(db_session),u=Depends(user)):
 s=db.get(m.Slot,d.slot_id)
 if not s or d.lecture_date.strftime('%A')!=s.day: raise HTTPException(400,'Invalid lecture date')
 p=db.scalar(select(m.Proxy).where(m.Proxy.slot_id==s.id,m.Proxy.lecture_date==d.lecture_date,m.Proxy.status=='ASSIGNED'))
 taker=p.proxy_faculty_id if p else s.faculty_id
 if u.role=='FACULTY' and u.faculty_id!=taker: raise HTTPException(403)
 if db.scalar(select(m.Attendance.id).where(m.Attendance.slot_id==s.id,m.Attendance.lecture_date==d.lecture_date)): raise HTTPException(409,'Already submitted; no overwrite')
 ids={x.id for x in db.scalars(select(m.Student).where(m.Student.course==s.course,m.Student.semester==s.semester,m.Student.division==s.division)).all()}
 if not ids or set(d.entries)!=ids: raise HTTPException(400,'Submit attendance for entire roster')
 for student_id,present in d.entries.items(): db.add(m.Attendance(slot_id=s.id,lecture_date=d.lecture_date,student_id=student_id,taken_by=taker,attendance_type='PROXY' if p else 'REGULAR',present=present))
 db.commit(); return {'saved':len(ids),'type':'PROXY' if p else 'REGULAR'}
@app.get('/api/attendance/report')
def attendance_report(db:Session=Depends(db_session),u=Depends(roles('ADMIN','HOD'))):
 return [{'slot_id':a.slot_id,'date':a.lecture_date,'student_id':a.student_id,'taken_by':a.taken_by,'type':a.attendance_type,'present':a.present} for a in db.scalars(select(m.Attendance)).all()]
