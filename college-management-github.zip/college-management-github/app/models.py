from sqlalchemy import Column, Integer, String, Date, ForeignKey, UniqueConstraint, Boolean
from .db import Base
class User(Base):
 __tablename__='users'
 id=Column(Integer,primary_key=True); username=Column(String,unique=True,nullable=False); password_hash=Column(String,nullable=False); role=Column(String,nullable=False); faculty_id=Column(Integer,ForeignKey('faculty.id'),nullable=True)
class Faculty(Base):
 __tablename__='faculty'
 id=Column(Integer,primary_key=True); code=Column(String,unique=True,nullable=False); name=Column(String,nullable=False); department=Column(String,nullable=False)
class Student(Base):
 __tablename__='students'
 id=Column(Integer,primary_key=True); enrollment=Column(String,unique=True,nullable=False); name=Column(String,nullable=False); course=Column(String,nullable=False); semester=Column(Integer,nullable=False); division=Column(String,nullable=False)
class Subject(Base):
 __tablename__='subjects'
 id=Column(Integer,primary_key=True); code=Column(String,unique=True,nullable=False); name=Column(String,nullable=False); course=Column(String,nullable=False); semester=Column(Integer,nullable=False)
class Inquiry(Base):
 __tablename__='inquiries'
 id=Column(Integer,primary_key=True); name=Column(String,nullable=False); phone=Column(String,nullable=False); course=Column(String,nullable=False); status=Column(String,default='NOT_ADMITTED')
class Intake(Base):
 __tablename__='intakes'
 id=Column(Integer,primary_key=True); course=Column(String,unique=True,nullable=False); capacity=Column(Integer,nullable=False)
class Admission(Base):
 __tablename__='admissions'
 id=Column(Integer,primary_key=True); inquiry_id=Column(Integer,ForeignKey('inquiries.id'),unique=True,nullable=False); status=Column(String,default='FINAL')
class Slot(Base):
 __tablename__='slots'
 id=Column(Integer,primary_key=True); day=Column(String,nullable=False); period=Column(Integer,nullable=False); faculty_id=Column(Integer,ForeignKey('faculty.id'),nullable=False); subject_id=Column(Integer,ForeignKey('subjects.id'),nullable=False); course=Column(String,nullable=False); semester=Column(Integer,nullable=False); division=Column(String,nullable=False); room=Column(String,default=''); __table_args__=(UniqueConstraint('day','period','faculty_id',name='uq_faculty_period'),UniqueConstraint('day','period','course','semester','division',name='uq_class_period'))
class Leave(Base):
 __tablename__='leaves'
 id=Column(Integer,primary_key=True); faculty_id=Column(Integer,ForeignKey('faculty.id'),nullable=False); start=Column(Date,nullable=False); end=Column(Date,nullable=False); leave_type=Column(String,nullable=False); reason=Column(String,default=''); status=Column(String,default='PENDING')
class Proxy(Base):
 __tablename__='proxies'
 id=Column(Integer,primary_key=True); slot_id=Column(Integer,ForeignKey('slots.id'),nullable=False); lecture_date=Column(Date,nullable=False); original_faculty_id=Column(Integer,ForeignKey('faculty.id'),nullable=False); proxy_faculty_id=Column(Integer,ForeignKey('faculty.id'),nullable=False); status=Column(String,default='ASSIGNED'); __table_args__=(UniqueConstraint('slot_id','lecture_date',name='uq_slot_proxy'),)
class Attendance(Base):
 __tablename__='attendance'
 id=Column(Integer,primary_key=True); slot_id=Column(Integer,ForeignKey('slots.id'),nullable=False); lecture_date=Column(Date,nullable=False); student_id=Column(Integer,ForeignKey('students.id'),nullable=False); taken_by=Column(Integer,ForeignKey('faculty.id'),nullable=False); attendance_type=Column(String,nullable=False); present=Column(Boolean,nullable=False); __table_args__=(UniqueConstraint('slot_id','lecture_date','student_id',name='uq_student_lecture'),)
