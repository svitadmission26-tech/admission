# SVIT Admission ERP — React + Node.js + npm + Supabase

**Working starter application, not a certified production ERP.** This is a fresh Node/Supabase implementation, not a rename of the old Laravel ZIP. Includes a designed React admin/student interface, Supabase Auth, PostgreSQL schema with RLS, CRUD for masters/configuration, dynamic form JSON editor, student submission, admin review, private document upload, manual fee tables, merit data tables, and basic CSV report. Advanced merit calculation engine, receipt PDF, payment gateway, detailed report builder, audit automation, and production integration tests remain to be implemented.

## Run locally
1. Install Node.js 20.19+ or 22.12+ and npm.
2. Create a NEW Supabase project. In its SQL Editor execute `supabase/migrations/001_init.sql` **once**. Review schema and policies before production.
3. Copy `.env.example` to `.env.local` and enter your Supabase project URL and public anon/publishable key.
4. In this directory:
   ```bash
   npm install
   npm run dev
   ```
   Open the Vite URL, usually http://localhost:5173.
5. Register an account in the UI. Confirm email if enabled. To grant admin, find that user's UUID in Supabase Authentication → Users and execute in the trusted SQL editor:
   ```sql
   update public.profiles set role='admin' where id='REPLACE_WITH_USER_UUID';
   ```
   Sign out and back in. **Never add an admin-role self-service registration button.**
6. Optional Node/Express health endpoint: copy `server/.env.example` to `server/.env`, then `npm run server`; GET http://localhost:3001/api/health. Data operations currently use Supabase client + database RLS, not this optional server.

## Form builder
Admin → Form Builder → Add New. Use `status=published` and valid `fields` JSON, e.g.:
```json
[{"key":"full_name","label":"Full Name","type":"text","required":true},{"key":"category","label":"Category","type":"select","required":true,"options":["General","Other"]}]
```
Students see the first published form in My Applications. For real use, enforce versioning, field validation and category policies server-side.

## Important limitations / security
- This is a demonstrable starter and has not undergone browser, end-to-end, security or load testing.
- RLS restricts application visibility and admin operations. Review policies with your institution before live use.
- The form JSON and fee/merit rules require stronger server-side validation and immutable published snapshots.
- Document upload accepts PDF/JPEG/PNG max 5 MB; storage is private. Add antivirus scanning, upload ownership verification, retention rules, and audit logging.
- Fees are in integer **paise**; payments are **manual records**, not online transactions. Implement idempotency/reconciliation before accepting payments.
- Merit entries are manual records; **automatic merit formula engine is not yet implemented**.
- Basic CSV reporting is for starter use only; extend server-side authorization and export auditing.
- Never commit `.env.local`, service role keys, student data, or payment credentials. Never put service keys in `VITE_` variables.
- Test authorization, backups, accessibility, consent, legal retention, and recovery in staging before production.

## Modules
Dashboard, Universities, Colleges, Courses, Branches, Academic Years, Dynamic Form Builder, Applications, Documents, Fee Structures, Fee Assignments, Manual Payments, Merit Schemes, Merit Entries, Basic Reports, Student Applications.

## Deployment
Build UI with `npm run build`, deploy `dist/` to a static host and configure environment values in the build system. Configure allowed redirect origins in Supabase Auth. Host optional Express separately. Use separate staging and production Supabase projects. Run security/UAT gates before live admissions.
