# Dynamic Admission Form Builder

Admin → Form Builder: create draft, add/edit/reorder fields, live preview, publish, duplicate published form. Published forms are locked in the UI. Supported field types: text, email, tel, number, date, textarea, select, radio, checkbox. Fields are stored in `admission_forms.fields` JSONB in the existing Supabase `001_init.sql` schema.

## Important integration/security notes
- No extra migration required for this module on the supplied starter schema.
- **Before real deployment:** enforce published-form immutability, allowed field types, required fields, option validation, application version snapshots, and course mapping on the database/server (UI validation alone is not security).
- Student rendering in existing `main.jsx` currently handles select/text/number/date/email, not all the new field types. Extend the student renderer and validate submissions server-side before live admissions.
- This builder currently selects a single published form for student display; course-wise selection must be implemented before production.
- Test `npm install && npm run build`, Supabase RLS, student submissions, and admin permissions in staging.
