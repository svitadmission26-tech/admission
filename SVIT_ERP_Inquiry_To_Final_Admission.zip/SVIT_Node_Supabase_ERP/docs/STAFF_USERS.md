# Dynamic Staff Users & Roles

Admin-only user management is available in the sidebar. Admin enters name, email, role and optional department; backend sends a Supabase Auth invitation. Staff never receive a plaintext password. Admin can edit staff role, department and active status.

Roles: Administrator, Admission Authority, Fees Collection, ID Card Operator, Data Entry Operator, Department Head, Principal. Permissions are stored in `staff_roles`, `role_permissions`, `staff_members`; `has_permission()` checks active membership. `department_head` application visibility/review is department-scoped.

## Installation
1. Existing Supabase development project: run `001_init.sql` if not already run, then `002_staff_roles.sql` exactly once.
2. Create initial admin via trusted SQL editor after sign-up: `update public.profiles set role='admin' where id='AUTH_USER_UUID';`
3. Copy `server/.env.example` to `server/.env` and enter URL, anon key and server-only service-role key. NEVER commit it or place it in Vite variables.
4. Add `VITE_API_BASE_URL=http://localhost:3001/api` to `.env.local`.
5. `npm install`, run `npm run server` and `npm run dev` in separate terminals. Configure Supabase Auth email invite redirect and SMTP for reliable invitation delivery.
6. Admin → User Management → Send Invitation. User accepts invitation by email.

## Important status
Staff creation and role assignment UI/API implemented. Application review RPC exists for authorized staff; other role-specific screens, fee collection workflows, ID-card generation, principal approval and comprehensive permission wiring are **not yet implemented**. Do not interpret the presence of a role as a complete operational module. Review RLS and test with separate accounts before live use.
