# Inquiry ID → Final Admission

Run SQL migration `005_inquiry_admission.sql` after 001–004 in a fresh development Supabase project. Public form `/#/inquiry` returns an opaque `INQ-...` reference. Authorized staff log in, open **Final Admissions**, enter this Inquiry ID and click **Fetch Inquiry Data**. A staff-only RPC copies the existing inquiry's name, mobile, email, course, branch, qualification and city into a uniquely linked admission record; re-fetching the same Inquiry ID returns the same record rather than creating duplicates.

Admin/Admission Authority can edit fetched details and save a decision: **Pending**, **Admitted** (requires enrollment number), or **Not Admitted** (requires a reason). Data Entry can prepare/fetch but cannot finalize. Principal/Department Head have read-only lists. Admitted decision also marks inquiry `converted`; all decisions are logged in `audit_logs`. Lists can filter and export CSV.

## Important boundaries
This is an **inquiry-linked final admission register**. It does not automatically create a Supabase student Auth account or an `applications` row, nor does it automatically issue a Smart ID Card; those flows need an explicit student-identity linking and verification workflow. Do not assume an inquiry alone establishes eligibility. Review admission rules, privacy, RLS, decision approvals and migration execution in staging. Public inquiries require CAPTCHA and rate limiting before going live.
