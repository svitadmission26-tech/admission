# SVIT Smart ID Cards

## Included
Admin/ID Card Operator screen, approved-application selector, manual student/enrollment/course/branch/year fields, unique generated card number, private optional photo, print-ready 86 × 54 mm card, QR encoding only the opaque card number, issue/reprint/revoke audit events. Supabase guarded RPCs check `id_cards.manage`; RLS limits reads.

## Setup
1. Apply migrations in order: `001_init.sql`, `002_staff_roles.sql`, then `003_smart_id_cards.sql` on a development Supabase project.
2. `npm install` (adds `qrcode`); configure `.env.local`; `npm run dev`.
3. Admin can assign ID Card Operator in User Management (requires optional Node server and its private `.env`).
4. Approve a test application first. Select it in Smart ID Cards, complete fields, issue, preview, and print.
5. Optional photo path must refer to an existing private `student-documents` object under the student's UUID folder. Upload photo via existing private Documents screen.

## Not included
Public QR verification website/API, NFC/RFID hardware integration, bulk generation, PDF export, card printer driver support, signature/college branding customization, automatic enrollment allocation, automated photo capture, production testing. QR is NOT proof of authenticity without a secure verification service. This is a starter module; do not print real credentials until UAT and policy review.
