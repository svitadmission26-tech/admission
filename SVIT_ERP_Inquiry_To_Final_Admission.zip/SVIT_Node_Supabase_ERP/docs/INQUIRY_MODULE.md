# Public Inquiry + Admin Dashboard + Follow-up

## Installation
Run SQL migrations 001 → 002 → 003 → **004_inquiries.sql** in a development Supabase project. Add your public Supabase URL and anon key to `.env.local`; `npm install && npm run dev`. Public inquiry: `http://localhost:5173/#/inquiry`. Admin login: root URL. Inquiries sidebar is available to admin, authority, data_entry, principal and department_head. Principal and department_head are read-only; admin, authority and data_entry can record follow-ups.

## Features
Responsive public form, required consent, mobile/email validation, honeypot field, opaque inquiry reference, RLS-protected inquiry data, status filters, search, follow-up due count, status/outcome/contact method/next date and chronological history. Public RPC allows submission without exposing inquiry table SELECT to anonymous users.

## Production gates (mandatory)
Add CAPTCHA/Turnstile verification and IP/device rate limiting **at an Edge Function or API gateway** before exposing public RPC. Honeypot alone is not bot protection. Review privacy notice/consent, retention, access logs, lead assignment, deduplication, SMS/email notifications and backup/restore. Current SQL RPC accepts anonymous traffic and must not be considered abuse-resistant. Run actual database integration tests and validate migrations in staging before live use.

## Notes
`source` and course options are currently frontend options; adapt them to approved college programs. This is an integrated starter, not a tested live admissions system.
